# encoding: utf-8
require "logstash/patches/bugfix_jruby_2558"
require "logstash/patches/cabin"
require "logstash/patches/profile_require_calls"
require "logstash/patches/stronger_openssl_defaults"
require "logstash/patches/exception_to_json"
