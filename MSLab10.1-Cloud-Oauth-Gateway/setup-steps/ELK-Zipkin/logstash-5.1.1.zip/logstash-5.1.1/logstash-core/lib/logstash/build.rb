# encoding: utf-8
BUILD_INFO = {"build_date"=>"2016-12-06T13:17:53+00:00", "build_sha"=>"aa36c4f4b702c6d379e5a97c22627933bca04f68", "build_snapshot"=>false}