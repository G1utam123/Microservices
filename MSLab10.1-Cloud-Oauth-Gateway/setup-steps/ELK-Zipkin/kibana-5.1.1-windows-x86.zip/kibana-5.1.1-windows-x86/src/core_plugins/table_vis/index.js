'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true
});

exports['default'] = function (kibana) {

  return new kibana.Plugin({
    uiExports: {
      visTypes: ['plugins/table_vis/table_vis']
    }
  });
};

;
module.exports = exports['default'];
